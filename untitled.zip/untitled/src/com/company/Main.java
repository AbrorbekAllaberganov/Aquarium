package com.company;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Main {

    public static void nasl() {
        FishService fishService = new FishService();
        int oldSize = fishList.size();
        fishList = fishService.naslQoldirish(fishList, counter);
        if (fishList.size() > oldSize) {
            counter++;
            new Thread(fishList.get(oldSize), String.valueOf(fishList.size() - 1)).start();
        }
    }

    public static boolean getLive() {
        for (Fish fish : fishList) {
            if (fish.isLive)
                return true;
        }
        return false;
    }

    static List<Fish> fishList = new ArrayList<>();
    static int counter;

    public static void main(String[] args) {
        Random random = new Random();

        int n = random.nextInt(15);
        int m = random.nextInt(15);
        counter = n + m;
        for (int i = 1; i <= n + m; i++) {
            Fish fish;
            if (i < n)
                fish = new Fish(true, i);
            else
                fish = new Fish(false, i);
            fishList.add(fish);
            new Thread(fish, String.valueOf(i)).start();
        }

        Runnable nasl = new Runnable() {
            @Override
            public void run() {
                while (getLive()) {
                    nasl();
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                System.out.println("Tirik baliqlar qolmadi");
            }
        };

        new Thread(nasl).start();

    }
}
