package com.company;

import java.util.List;
import java.util.Random;

public class FishService {

    public List<Fish> naslQoldirish(List<Fish> fishList,int counter) {
        Random random = new Random();
        int first = random.nextInt(fishList.size()-1);
        int second = first;
        while (second == first) {
            second = random.nextInt(fishList.size()-1);
        }

        if (fishList.get(first).isLive && fishList.get(second).isLive
                && (!fishList.get(first).jins == fishList.get(second).jins)){
            int jins=random.nextInt(2);
            System.out.println(first+1+" va "+(second+1)+" nasl qoldirdi => id si "+(++counter));
            fishList.add(new Fish(jins==1,counter));
        }
        return fishList;
    }

}
